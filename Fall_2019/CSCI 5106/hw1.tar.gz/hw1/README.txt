In this directory includes:
 - The C file hw1.c
 - The Java file hw1.java
 - The Scheme file hw1.scm
 - The Standard ML file hw1.sml
 - The Prolog file hw1.pl

Each file contains implementations, and tests for a list manipulation function
with the exception of the Prolog file which requires user given values for
it's function to be tested.
